from django.contrib import admin
from core.models import Users,Movies,Seat
# Register your models here.

admin.site.register(Users)
admin.site.register(Movies)
admin.site.register(Seat)