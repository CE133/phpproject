from django import forms
from core.models import Users
class Register(forms.ModelForm):
    class Meta:
        model=Users
        fields='__all__'
