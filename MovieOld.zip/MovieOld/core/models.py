from django.db import models

# Create your models here.
class Users(models.Model):
    username=models.CharField(max_length=50,unique=True)
    emailid=models.EmailField(max_length=254,unique=True)
    password=models.CharField(max_length=30,unique=True)
    country=models.CharField(max_length=20, null=True)
    favmovgenre=models.CharField(max_length=25,null=True)

class Movies(models.Model):
    movie_title=models.CharField(max_length=50,unique=True)
    price=models.IntegerField(null=True)
    genre=models.CharField(max_length=50)
    posterlink=models.URLField( max_length=500,unique=True)
    trailerlink=models.URLField( max_length=200,unique=True)
    story=models.CharField(max_length=500,unique=True)
    actors=models.CharField(max_length=300,unique=True)
    release=models.DateField(auto_now=False, auto_now_add=False)
    time=models.CharField(max_length=200,null=True)#ShowDate
    showtime=models.CharField(max_length=200,null=True)

class Seat(models.Model):
  #  screening=models.ForeignKey(Screening, on_delete=models.CASCADE,null=True)
    movie=models.ForeignKey(Movies, on_delete=models.CASCADE,null=True)
    # seat_id = models.CharField(max_length=10, primary_key=True, editable=False)#row_col
    row=models.IntegerField(null=True)
    col=models.IntegerField(null=True)
    isReserved=models.BooleanField(default=False)
# class Seat(models.Model):
#     total_seats=models.CharField(max_length=50,unique=True)
#     seats_booked=models.CharField(max_length=50,unique=True)
#     seats_available=models.CharField(max_length=50,unique=True)

# class Tickets(models.Model):
#     movie_title=models.CharField(max_length=50,unique=True)
#     total_tickets_bought=models.IntegerField()
#     total_price=models.IntegerField()
#     seats_allocated=models.IntegerField()


    
# class Reservation(models.Model):
#    # screening=models.ForeignKey(Screening, on_delete=models.CASCADE)
#     seat=models.ForeignKey(Seat, on_delete=models.CASCADE)
#     paid=models.BooleanField(default=False)
# #    employee_paid_id
# #    employee_reserved_id