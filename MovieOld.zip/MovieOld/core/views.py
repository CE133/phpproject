from django.shortcuts import render,get_object_or_404
from django.http import HttpResponse
from core.forms import Register
from . import forms
from core.models import Movies,Seat
from core.models import Users
from difflib import SequenceMatcher
import operator
from django.http.response import HttpResponseRedirect
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.csrf import csrf_exempt
import re
# Create your views here.
loge=False
une=''
error=''
def index(request):
    all_movies=Movies.objects.all()
    return render(request,'core/index.html',{'all_movies':all_movies,'error':error,'log':False})

def RegisterForm(request):
    form=forms.Register()
    if request.method=="POST":
        form =forms.Register(request.POST)
        if form.is_valid():
            form.save(commit=True)
            msg="Hello!!! Successfully Registered"
            user=request.POST.get('username')
            return render(request,'core/index.html',{'msg':"You Have Succefully registered","user":user,"log":True})
    else:
        return render(request,'core/register.html',{'registerform':form,'log':False})

def login(request):
    error=''
    uname=request.POST.get('username')
    pword=request.POST.get('password')
    result=Users.objects.all()
    if request.method=='POST':
        for i in result:
            if uname == i.username and pword == i.password:
                error=''
                loge=True
                une=uname
                print(loge,une)
                return render(request,'core/index.html',{"user":uname,"log":True})
                break
            else:
                error='Wrong'
    return render(request,'core/Login.html',{'error':error})

def detail(request,movie_id):
    movie = get_object_or_404(Movies,pk=movie_id)
    return render(request,'core/detail.html',{'movie' : movie,"user":une,"log":loge})

def book(request,movie_id):
    movie = get_object_or_404(Movies,pk=movie_id)
    l=[]
    rs=[]
    s="["
    le=0
    l = list(Seat.objects.filter(movie=movie))
    for i in l:
        if i.isReserved==True:
            #s=s+"'"+str(i.row)+"_"+str(i.col)+"',"
            rs.append(str(i.row)+"_"+str(i.col))
            # print(i.seat_id)       
            le=le+1 
    # s=s+"]"
    # print(rs)
    # print(le)  
    return render(request,'core/book.html',{'movie' : movie,"ReservedSeats":l,"len":le})    

def search(request):
    movielist={}
    final=[]
    if request.method == 'POST':
        search=request.POST.get('q')
        all=Movies.objects.all()
        for i in range(0,len(all)):
            print(search,all[i].movie_title)
            m = int(SequenceMatcher(None,str(search).lower(),str(all[i].movie_title).lower()).ratio()*100)
            movielist[m]=all[i]
        sorted_d = sorted(movielist.items(), key=operator.itemgetter(0),reverse=True)
        for i in range(0,len(movielist)):
            if sorted_d[i][0]>50:
                final.append(sorted_d[i][1])
                print(une,loge)
        return render(request,'core/search.html',{'final' : final,"user":une,"log":loge,"length":len(final)})  
    return render(request,'core/search.html',{'final' : final,"user":une,"log":loge})  

# def update(request):
#     if request.method == 'POST':
#         seat = Seat.objects.get()
#         seat.movie = request.POST['movie']
#         seat.row = request.POST['row']
#         seat.col = request.POST['col']
#         seat.seat_id = request.POST['id']
#         seat.save()
#         message = 'update successful'
#     return HttpResponse(message)


def pay(request,movie_id):
    movie = get_object_or_404(Movies,pk=movie_id)
    seats=request.GET.get('seats')
    total=request.GET.get('total')
    return render(request,'core/pay.html',{'seats' : seats,"total":total, 'movie':movie})
       
def confirm(request,movie_id):
    movie = get_object_or_404(Movies,pk=movie_id)
    if request.method == 'POST':
        seats=request.POST.get('seats')
        total=request.POST.get('total')
        l=[int(s) for s in re.findall(r'\d+', seats)]
        f=True
        r=0
        c=0
        count=0
        for i in l:
            if f:
                r=i
                f=False
                count=count+1
            else:
                c=i
                f=True
                count=count+1
            if count==2:
                count=0
                print(r)
                print(c)
        #         obj=Seat(movie=movie,row=r,col=c,isReserved=True)
        #         obj.save()
        # print(seats)
        
        
        #print(seats)
        return render(request,'core/confirm.html',{'seats' : seats,"total":total, 'movie':movie})
    return render(request,'core/confirm.html',{'movie':movie}) 